def some_function():
    # Shared logic here
    pass
